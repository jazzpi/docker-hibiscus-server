-- ----------------------------------------------------------------------
-- Erweitert die Tabelle "sepalastschrift" um eine Spalte "sequencetype"
-- ----------------------------------------------------------------------

alter table sepalastschrift add sequencetype VARCHAR(8) NOT NULL;
