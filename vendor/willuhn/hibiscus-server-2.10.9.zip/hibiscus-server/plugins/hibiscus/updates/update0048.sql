-- ----------------------------------------------------------------------
-- Erweitert die Tabelle "sepalastschrift" um die Spalte "orderid" - das ist die Rueckmeldung der Bank
-- ----------------------------------------------------------------------

alter table sepalastschrift add orderid varchar(255);
