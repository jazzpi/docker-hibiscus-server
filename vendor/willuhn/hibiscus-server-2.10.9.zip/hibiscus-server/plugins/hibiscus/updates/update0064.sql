-- ----------------------------------------------------------------------
-- Fuehrt die neue Spalte "endtoendid" ein.
-- ----------------------------------------------------------------------

ALTER TABLE umsatz ADD endtoendid varchar(100);
