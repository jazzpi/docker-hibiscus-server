-- ----------------------------------------------------------------------
-- Erweitert die Tabelle "konto" um eine Spalte "kategorie"
-- ----------------------------------------------------------------------

alter table konto add kategorie VARCHAR(255) NULL;
