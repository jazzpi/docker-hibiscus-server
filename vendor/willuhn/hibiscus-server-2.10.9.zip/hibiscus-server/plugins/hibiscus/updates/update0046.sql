-- ----------------------------------------------------------------------
-- Erweitert die Tabelle "sepalastschrift" um eine Spalte "creditorid"
-- ----------------------------------------------------------------------

alter table sepalastschrift add creditorid VARCHAR(35) NOT NULL;
